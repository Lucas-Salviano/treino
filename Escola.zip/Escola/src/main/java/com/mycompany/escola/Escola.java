

package com.mycompany.escola;

/**
 *
 * @Lucas salviano
 */
public class Escola {

    public static void main(String[] args) {
        
        Aluno[] alunos = new Aluno[3];
        
        alunos[0] = new Aluno("mario","e.Comp",19);
        alunos[1] = new Aluno("keltu","e.Civil",19);
        alunos[2] = new Aluno("leandro","Direito",19);
        
        System.out.println("imprimir informações: ");
        
        for(Aluno aluno : alunos){ //verifica numero no array para executar na classe citada 
            aluno.imprime();
        }
        
    }
}
