package com.mycompany.mavenproject1;

/**
 *
 * @author Lucas Salviano
 */
public class Mavenproject1 {

    public static void main(String[] args) throws Exception {

        int[] arr = new int[5]; //dclara lista

        arr[0] = 10;
        arr[1] = 20;
        arr[2] = 30;
        arr[3] = 40;
        // arr[4] = 50; // o array tem tamanho fixo

        for (int i = 0; i < arr.length; i++) { //arr.length verifica o numero de posições do array
            System.out.println(arr[i]);
        }

    }
}
