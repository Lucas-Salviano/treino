/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.atividade2;

import java.util.Random;

/**
 *
 * @author 23300012
 */
public class Atividade2 {

    public static void main(String[] args) throws Exception {
        int soma = 0;
        int[][] arr = new int[4][4];

        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                Random random = new Random();
                int number = random.nextInt(16);
                
                    arr[i][j] = number + 1;
                

            }
        }
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.println(arr[i][j]);
            }

        }
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
               soma = soma + arr[i][j]; 
              
            }

        }
        System.out.println("a soma é "+ soma);

    }
}
