/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.atividade1;

/**
 *
 * @author 23300012
 */
public class Atividade1 {

    public static void main(String[] args) throws Exception {

        String[] arr = new String[12];

        arr[0] = "january";
        arr[1] = "february";
        arr[2] = "march";
        arr[3] = "april";
        arr[4] = "may";
        arr[5] = "june";
        arr[6] = "july";
        arr[7] = "august";
        arr[8] = "september";
        arr[9] = "october";
        arr[10] = "november";
        arr[11] = "december";

        for (int i = 0; i < arr.length; i++) {
            if (arr[i].length() > 5) {
                System.out.println(arr[i]);
            }
        }

    }
}
