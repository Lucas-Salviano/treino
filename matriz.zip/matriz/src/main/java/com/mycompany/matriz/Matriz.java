/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.matriz;

/**
 *
 * @author 23300012
 */
public class Matriz {

    public static void main(String[] args) throws Exception{
        
        int[][] arr = new int [3][3];
        
        System.out.println("numero de linhas: "+ arr.length);
        System.out.println("numero de colunas: "+ arr[0].length);
        
    }
}
